//
//  ViewController.swift
//  HW3
//
//  Created by Chung, Hyun Shik on 11/7/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
var contries = [String]()
var city = [String]()
var user_choice_contry:String = ""
var user_choice_city:String = ""
class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        contries.append(contentsOf: AppData.cities.keys)
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

extension ViewController: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
       return contries.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let aCountry = contries[section]
        let cities = AppData.cities[aCountry]
        return (cities?.count)!
    }
   
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
       
        return contries[section]
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)
        let aCountry = contries[indexPath.section]
        let cities = AppData.cities[aCountry]
        cell.textLabel!.text = cities![indexPath.row]
        
        
        return cell
    }
    
    
}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        user_choice_contry = contries[indexPath.section]
        let contry = contries[indexPath.section]
        let cities = AppData.cities[contry]
        user_choice_city = cities![indexPath.row]
        self.performSegue(withIdentifier: "passToCurrentVC", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        
        let goToSecView = segue.destination as! CurrentWeatherViewController
        goToSecView.country = user_choice_contry
        goToSecView.citiy = user_choice_city
        tableView.reloadData()
        
    }
}
