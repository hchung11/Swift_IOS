//
//  ForcastViewController.swift
//  HW3
//
//  Created by Chung, Hyun Shik on 11/7/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import Alamofire
import AlamofireImage


class ForcastViewController: UIViewController,UITableViewDataSource{
    //recieve from CurrentWetherViewController
  var forcastD = [ForcastData]()
    
    var iconImageses = [UIImage]()
    var forcastCountry:String = ""
    var forcastCitiy:String = ""
   @IBOutlet weak var cityCountryLabel: UILabel!
    @IBOutlet weak var testImage: UIImageView!
    override func viewDidLoad() {
       super.viewDidLoad()
        print(self.iconImageses.count)
     cityCountryLabel.text = "\(forcastCitiy),\(forcastCountry)"
    }
      @IBOutlet weak var tableView: UITableView!
    override func viewWillAppear(_ animated: Bool) {
       
        print(forcastD.count)

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        
        print ("print something===",forcastD.count)
        //should be 40
        let total = forcastD.count
        return total
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCellOnFor", for: indexPath)
        //i decide to use viewWithTag(you can use Nib)
        let everyThreehour = cell.viewWithTag(100) as! UILabel
        let temp = cell.viewWithTag(200) as! UILabel
         let tempMax = cell.viewWithTag(300) as! UILabel
        let tempMin = cell.viewWithTag(400) as! UILabel
         let hum = cell.viewWithTag(500) as! UILabel
        let desc = cell.viewWithTag(600) as! UILabel
        let iconImage = cell .viewWithTag(1) as! UIImageView
        everyThreehour.text = self.forcastD[indexPath.row].threeHourData
        temp.text = "\((self.forcastD[indexPath.row].temp)!) F"
        tempMax.text =  "MAX: \((self.forcastD[indexPath.row].temp_max)!) F"
        tempMin.text =  "MIN: \((self.forcastD[indexPath.row].temp_min)!) F"
        hum.text = "Humidity: \((self.forcastD[indexPath.row].humidity)!) %"
        desc.text = self.forcastD[indexPath.row].description
        iconImage.image = self.iconImageses[indexPath.row]

        return cell
    }
    
    

}

