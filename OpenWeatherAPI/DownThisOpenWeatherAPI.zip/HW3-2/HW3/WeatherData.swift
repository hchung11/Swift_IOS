//
//  WeatherData.swift
//  HW3
//
//  Created by Chung, Hyun Shik on 11/7/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import Foundation
import SwiftyJSON
//{"main"{},"wind"{},"weather"{[]},"clouds"{}}
class WeatherData {
        
        
        var main:Main?
        var wind:Wind?
        var weather:Weather?
        var clouds:Clouds?
        var date:ThreeDate?
        init(json:JSON){
            //self.date = ThreeDate(json: <#T##JSON#>)
            self.main = Main(json: json["main"])
            self.wind = Wind(json: json["wind"])
            self.weather = Weather(json: json["weather"][0])
            self.clouds = Clouds(json: json["clouds"])
        }
        
    }
//inside main{}
    class Main {
        var temp:String?
        var temMax:String?
        var temMin:String?
        var humidity:String?
        
        init(json: JSON) {
            self.temp = json["temp"].stringValue
            self.temMax = json["temp_max"].stringValue
            self.temMin = json["temp_min"].stringValue
            self.humidity = json["humidity"].stringValue
        }
    }
    //insde weather{[]}
    class Weather {
        var description:String?
        var icon:String?
        
        init(json: JSON){
            self.description = json["description"].stringValue
            self.icon = json["icon"].stringValue
        }
    }
    //inside wind{}
    class Wind {
        var speed:String?
        var degree:String?
        
        init(json: JSON){
            self.speed = json["deg"].stringValue
            self.degree = json["speed"].stringValue
        }
    }
    //inside clouds{}
    class Clouds {
        var cloudiness:String?
        
        init(json: JSON){
            self.cloudiness = json["all"].stringValue
        }

}

class ThreeDate {
    var date:String?
    init (json: JSON){
        self.date = json["dt_txt"].stringValue
    }
}
/*JSON Data
 {
   "dt" : 1573446447,
   "timezone" : -18000,
   "clouds" : {
     "all" : 1
   },
   "sys" : {
     "id" : 4686,
     "country" : "US",
     "sunset" : 1573422189,
     "type" : 1,
     "sunrise" : 1573385800
   },
   "visibility" : 16093,
   "coord" : {
     "lon" : -73.989999999999995,
     "lat" : 40.729999999999997
   },
   "name" : "New York",
   "id" : 5128581,
   "weather" : [
     {
       "id" : 800,
       "main" : "Clear",
       "icon" : "01n",
       "description" : "clear sky"
     }
   ],
   "main" : {
     "humidity" : 65,
     "temp_max" : 48.990000000000002,
     "temp_min" : 35.009999999999998,
     "temp" : 41.670000000000002,
     "pressure" : 1018
   },
   "base" : "stations",
   "cod" : 200,
   "wind" : {
     "speed" : 10.83,
     "deg" : 245
   }
 }
 */
