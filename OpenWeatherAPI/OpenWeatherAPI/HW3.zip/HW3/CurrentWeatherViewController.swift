//
//  CurrentWeatherViewController.swift
//  HW3
//
//  Created by Chung, Hyun Shik on 11/7/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage
import SwiftyJSON

class CurrentWeatherViewController: UIViewController {
    var country:String = ""
    var citiy:String = ""
    var addforcastD = [ForcastData]()
    var iconImages = [UIImage]()
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var temMaxLabel: UILabel!
    @IBOutlet weak var temMinLabel: UILabel!
    @IBOutlet weak var descrLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    
    @IBOutlet weak var windSpeedLabel: UILabel!
    @IBOutlet weak var windDegLabel: UILabel!
    @IBOutlet weak var cloudLabel: UILabel!
    var currentImageIcon: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        getCrrentWeather()
        getFocast()
        

        print (self.country , self.citiy)
        locationLabel.text = "\(citiy),\(country)"
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var iconImageView: UIImageView!
    func getCrrentWeather()  {
//====================================================================================
                //data in to current weather view
//====================================================================================
        Alamofire.request("http://api.openweathermap.org/data/2.5/weather?q=\(citiy.replacingOccurrences(of: " ", with: "%20")),\(country)&appid=4fbe1f35b2ec80f74e59553e28248e4c&units=imperial").responseJSON (completionHandler: {(response) in
            switch response.result {
            case .success:
                let data = JSON(response.result.value!)
                //let test = data["coord"][""]
                let weather_data = WeatherData(json: data)
                print(data)
                self.tempLabel.text = "\((weather_data.main?.temp)!) F"
                self.temMaxLabel.text = "\((weather_data.main?.temMax)!) F"
                self.temMinLabel.text = "\((weather_data.main?.temMin)!) F"
                self.descrLabel.text = weather_data.weather?.description
                self.humidityLabel.text = "\((weather_data.main?.humidity)!) %"
                self.windSpeedLabel.text = "\((weather_data.wind?.speed)!) miles/hr"
                self.windDegLabel.text = "\((weather_data.wind?.degree)!) degree"
                self.cloudLabel.text = "\((weather_data.clouds?.cloudiness)!) %"
                self.currentImageIcon = (weather_data.weather?.icon)!
                print("Validation Successful------", self.currentImageIcon)
                Alamofire.request("http://openweathermap.org/img/wn/\(self.currentImageIcon)@2x.png").responseImage { response in
                    debugPrint(response)

                    print(response.request)
                    print(response.response)
                    debugPrint(response.result)

                    if let image = response.result.value {
                        self.iconImageView.image = image
                        print("ssddsdssss",image)
                    }
                }
            case let .failure(error):
                print(error,self.currentImageIcon)
            }
        })
        
 //==================================================================================
    }
func getFocast()  {

//-------------------------------------------------------------------------------------
                //create object ForcastData for the 3hour and 5day weather
                //add object to array and pass to ForcastViewController
//-------------------------------------------------------------------------------------
                Alamofire.request("http://api.openweathermap.org/data/2.5/forecast?q=\(citiy.replacingOccurrences(of: " ", with: "%20")),\(country)&appid=4fbe1f35b2ec80f74e59553e28248e4c&units=imperial").responseJSON (completionHandler: {(response) in
                    switch response.result {
                    case .success:
                        let data = JSON(response.result.value!)

                        let soemsomte = data["list"]
                        print("====================", data,"===================")
                        for (num, list)in soemsomte {
                  
                           self.addforcastD.append(ForcastData(threeHour: list["dt_txt"].stringValue, temp: list["main"]["temp"].doubleValue, temp_max: list["main"]["temp_max"].doubleValue, temp_min: list["main"]["temp_min"].doubleValue, humidity: list["main"]["humidity"].intValue, description: list["weather"][0]["description"].stringValue, iconImage: list["weather"][0]["icon"].stringValue))
//                            print( "******",type(of: list),"*******")
//                            print("Date", list["dt_txt"])
//                            print ("Humidity",list["main"]["humidity"])
//                            print ("Temp",list["main"]["temp"])
//                            print ("Temp Max",list["main"]["temp_max"])
//                            print ("Temp Min",list["main"]["temp_min"])
                            let desc = list["weather"][0]["description"].stringValue
                            print ("Description",desc )
                            print("icon ", list["weather"][0]["icon"])
              

                            
                        }
//-------------------------------------------------------------------------------------
                        print("1111111111", self.addforcastD.count)
                        
//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//put all the image data into array so this can pass to next ForcastViewController
//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                        for (i) in self.addforcastD{
                                              let s = i.iconImage!
                            print ("sssssss",s)
                                          Alamofire.request("http://openweathermap.org/img/wn/\(s)@2x.png").responseImage { response in
                                              //debugPrint(response)
                                              //debugPrint(response.result)

                                              if let image = response.result.value {
                                                  self.iconImages.append(image)
                                                  print("ssddsdssss",image)
                                              }
                                          }
                                          }
//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
  
                        print("inside get--",self.addforcastD.count)
                        print("Validation Successful")
                    case let .failure(error):
                        print(error)
                    }
                })
    }
    
    @IBAction func forcastButton(_ sender: Any) {
        
        //self.performSegue(withIdentifier: "passToFrcast", sender: self)
    
 
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {


        let goToSecView = segue.destination as! ForcastViewController
        //pass user chooice to next viewController
        goToSecView.forcastCountry = self.country
        goToSecView.forcastCitiy = self.citiy
        goToSecView.forcastD = self.addforcastD
        goToSecView.iconImageses = self.iconImages

    }


}
