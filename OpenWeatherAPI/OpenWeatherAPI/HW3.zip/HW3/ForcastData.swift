//
//  ForcastData.swift
//  HW3
//
//  Created by Jerry Zacharias on 11/8/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import Foundation
class ForcastData{
    var threeHourData:String?
    var temp: Double?
    var temp_max:Double?
    var temp_min:Double?
    var humidity: Int?
    var description:String?
    var iconImage:String?
    
    init(threeHour:String, temp:Double, temp_max:Double, temp_min:Double, humidity:Int, description :String, iconImage:String) {
        self.threeHourData = threeHour
        self.temp = roundOne(num: temp)
        self.temp_max = roundOne(num: temp_max)
        self.temp_min = roundOne(num: temp_min)
        self.description = description
        self.humidity = humidity
        self.iconImage = iconImage
        
    }
    func roundOne(num: Double) -> Double {
        return (num*10).rounded()/10
    }
    
}
