//
//  Aforum.swift
//  InClass10
//
//  Created by Jerry Zacharias on 12/2/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import Foundation
class Aforum {
    var msg:String?
    var currentUserID:String?
    var currentuserName:String?
    var unquID:String?
}
