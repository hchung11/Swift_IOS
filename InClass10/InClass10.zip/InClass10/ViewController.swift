//
//  ViewController.swift
//  InClass10
//
//  Created by Chung, Hyun Shik on 11/25/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import UIKit
import Firebase
class ViewController: UIViewController {
    @IBOutlet weak var emailTF: UITextField!
    
    @IBOutlet weak var passwordTF: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func loginSubmitButton(_ sender: Any) {
        let userEmail = emailTF.text
        let userPassword = passwordTF.text
        Auth.auth().signIn(withEmail: userEmail!, password: userPassword!) {authResult, error in
            if error != nil{
                let alert = UIAlertController(title: "Alert", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }else{
                print("Suesses!!")
                AppDelegate.forumsVC()
            }
        }
        
        
    }
    
    @IBAction func CreateNewIdButton(_ sender: Any) {
        AppDelegate.showSignUp()
    }
    
    
}

