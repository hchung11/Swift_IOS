//
//  CreateForumViewController.swift
//  InClass10
//
//  Created by Jerry Zacharias on 11/30/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import UIKit
import Firebase

class CreateForumViewController: UIViewController {
    let userID = Auth.auth().currentUser?.uid
    let ref = Database.database().reference()
    @IBOutlet weak var userMsg: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func newFroumSubmitButton(_ sender: Any) {
        ref.child("usrs").child(userID!).observe(.value, with: { (snapshot) in
          // Get user value
            let username = snapshot.childSnapshot(forPath: "name").value
            print("print somthing",username!)
            //Store all the forum msg in same data tree
            self.ref.child("forums").childByAutoId().setValue(["msg": self.userMsg.text! , "userID": self.userID! ,"name": username,"like": 0])
            self.dismiss(animated: true)
          // ...
          }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    @IBAction func cancel(_ sender: Any) {
        self.dismiss(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
