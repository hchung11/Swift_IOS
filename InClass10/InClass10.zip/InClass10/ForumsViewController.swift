//
//  ForumsViewController.swift
//  InClass10
//
//  Created by Chung, Hyun Shik on 11/25/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import UIKit
import Firebase
class ForumsViewController: UIViewController {
    var userID = Auth.auth().currentUser?.uid
    var ref = Database.database().reference()
    var allTheForums = [AllForums]()
    var forumid:String?
    var forumMsg:String?
    var forumLikes:String?
    var forumName:String?
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let cellNib = UINib(nibName: "ForumsTableViewCell", bundle: nil)
        tableView.register(cellNib, forCellReuseIdentifier: "forumCell")
        // Do any additional setup after loading the view.
        
        
        ref.child("forums").observe(.value, with: { (snapshot) in
              //print("3234897945====")
              //print(snapshot)
              self.allTheForums.removeAll()
              if snapshot.value != nil{
                  for ch in snapshot.children{
                      let some = AllForums()
                      let snapshotData = ch as! DataSnapshot
                      some.forumID = snapshotData.key
                      if snapshotData.hasChild("name") {
                          some.name = snapshotData.childSnapshot(forPath: "name").value as? String
                        print(snapshotData.childSnapshot(forPath: "name").value as? String!)
                      }
                      if snapshotData.hasChild("msg") {
                        some.msg = snapshotData.childSnapshot(forPath: "msg").value as? String
                      }
                      if snapshotData.hasChild("like") {
                        some.likes = snapshotData.childSnapshot(forPath: "like").value as? Int
                      }
                    if snapshotData.hasChild("userID") {
                        some.userID = snapshotData.childSnapshot(forPath: "userID").value as? String
                                        }
                    if snapshotData.hasChild("likebutton") {
                        some.likebutton = snapshotData.childSnapshot(forPath: "likebutton").value as? Int
                                                          }
                    //likebutton
                      self.allTheForums.append(some)
                      
                  }
                  print("")
                  self.tableView.reloadData()
              }
          })
    }
    
    @IBAction func addMsgButton(_ sender: Any) {
        
        AppDelegate.newForumsVC()
    }
    
    @IBAction func logoutButton(_ sender: Any) {
        AppDelegate.showLogin()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension ForumsViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.allTheForums.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "forumCell", for: indexPath) as! ForumsTableViewCell
        let somthing = self.allTheForums[indexPath.row].forumID
        cell.writerMsg.text = allTheForums[indexPath.row].msg
        cell.writerName.text = allTheForums[indexPath.row].name
        let likes = String((allTheForums[indexPath.row].likes)!)
        cell.writerLikes.text = likes
        
        cell.delegate = self
        if allTheForums[indexPath.row].userID != userID{
            cell.deleteButtonOutlet.isHidden = true
        }
        ref.child("forums").child(somthing!).child("usersLikes").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
        // Get user value
        let value = snapshot.value as? NSDictionary
        let likeit = value?["likebutton"] as? Int
        if likeit == 1{
            cell.button.setTitle("♥️", for: .normal )
        }else{
            cell.button.setTitle("♡", for: .normal )
        }
             }) { (error) in
                print(error.localizedDescription)
            }
        return cell
    }
    
    
}
extension ForumsViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.forumid = allTheForums[indexPath.row].forumID
        self.forumMsg = allTheForums[indexPath.row].msg
        self.forumName = allTheForums[indexPath.row].name
        self.forumLikes = String((allTheForums[indexPath.row].likes)!)
        self.performSegue(withIdentifier: "toForum", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let passID = segue.destination as? DetailForumViewController{
            passID.detailForumid = self.forumid!
            passID.detailMSG = self.forumMsg!
            passID.detailNAME = self.forumName!
            passID.detailLIKES = self.forumLikes!
        }
    }
}
extension ForumsViewController:LikeButtonDelegate{
    func likebuttonin(cell: ForumsTableViewCell) {
         let indexPath = self.tableView.indexPath(for: cell)
        let somthing = self.allTheForums[indexPath!.row].forumID
        
        ref.child("forums").child(somthing!).child("usersLikes").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
          // Get user value
          let value = snapshot.value as? NSDictionary
          let likeButton = value?["likebutton"] as? Int
            
            if likeButton == 1{
                self.ref.child("forums").child(somthing!).updateChildValues(["like": self.allTheForums[indexPath!.row].likes! - 1])
                self.ref.child("forums").child(somthing!).child("usersLikes").child(self.userID!).updateChildValues(["likebutton": -1])
                       cell.button.titleLabel?.text = ""
                        cell.button.setTitle("♥️", for: .normal )
                
                
                   }else{
                         self.ref.child("forums").child(somthing!).updateChildValues(["like": self.allTheForums[indexPath!.row].likes! + 1])
                self.ref.child("forums").child(somthing!).child("usersLikes").child(self.userID!).updateChildValues(["likebutton": 1])
                       cell.button.setTitle("♡", for: .normal )
                   }
                  

          // ...
          }) { (error) in
            print(error.localizedDescription)
        }
        print ("print form id ", somthing)
        
       
        
        //if currentuser selected than cannot like the button.
    }
    
    
    func deletebutton(cell: ForumsTableViewCell) {
        let destroyAction = UIAlertAction(title: "OK",style: .default) { (action) in
        let indexPath = self.tableView.indexPath(for: cell)
        
        
            if self.allTheForums[(indexPath?.row)!].userID == self.userID{
                self.ref.child("forums").child(self.allTheForums[indexPath!.row].forumID!) .removeValue()
        }
    }
                  let cancelAction = UIAlertAction(title: "Cancel",
                            style: .cancel) { (action) in
                   // Respond to user selection of the action
                  }
                 let alert = UIAlertController(title: "Delete the Threed?",
                               message: "",
                               preferredStyle: .actionSheet)
                   alert.addAction(destroyAction)
                   alert.addAction(cancelAction)
                  self.present(alert, animated: true)
        }
    }
    

