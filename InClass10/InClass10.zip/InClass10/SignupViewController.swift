//
//  SignupViewController.swift
//  InClass10
//
//  Created by Chung, Hyun Shik on 11/25/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import UIKit
import Firebase


class SignupViewController: UIViewController {
    var userID = Auth.auth().currentUser?.uid
    var ref = Database.database().reference()
    @IBOutlet weak var singupEmailTF: UITextField!
    
    @IBOutlet weak var signUpyourName: UITextField!
    @IBOutlet weak var signupPasswordTF: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func signUpButton(_ sender: Any) {
        
        //sign up the new user using Firebase
        let adduserInputEmail = singupEmailTF.text
        let adduserInputPassword = signupPasswordTF.text
        print(adduserInputPassword!)
//        if passwordTextField.text! == confirmPasswordTextField.text!{
            Auth.auth().createUser(withEmail: adduserInputEmail!, password: adduserInputPassword!) { authResult, error in
                if error != nil{
                    print("Error:  \(error.debugDescription)")
                    let alert = UIAlertController(title: "Alert", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    
                }
                else {
                    print("Successful!")
                    
                    
                    Auth.auth().signIn(withEmail: adduserInputEmail!, password: adduserInputPassword!) {authResult, error in
                        if error != nil{
                            let alert = UIAlertController(title: "Alert", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }else{
                            print("Suesses!!")
                            print("print name", self.signUpyourName.text!)
                            self.ref.child("usrs").child(Auth.auth().currentUser!.uid).setValue(["name": self.signUpyourName.text])
                            AppDelegate.forumsVC()
                        }
                    }
                    
                   // AppDelegate.forumsVC()
                }
           }
//        }else{
//            let alert = UIAlertController(title: "Alert", message: "Password is not match", preferredStyle: UIAlertController.Style.alert)
//            alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
//            self.present(alert, animated: true, completion: nil)
//        }

    }
    @IBAction func signUpCancel(_ sender: Any) {
        AppDelegate.showLogin()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
