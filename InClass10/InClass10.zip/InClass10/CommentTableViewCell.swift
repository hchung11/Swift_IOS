//
//  CommentTableViewCell.swift
//  InClass10
//
//  Created by Jerry Zacharias on 12/4/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import UIKit
protocol DeleteButtonDelegate {
    func deletebutton(cell:CommentTableViewCell)
    
}
class CommentTableViewCell: UITableViewCell {

    @IBOutlet weak var commentName: UILabel!
    @IBOutlet weak var commentMsg: UILabel!
    @IBOutlet weak var commentDeleteButtonOutlook: UIButton!
    var delegate: DeleteButtonDelegate?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func commentDeleteButton(_ sender: Any) {
        delegate?.deletebutton(cell: self)
    }
    
}
