//
//  ForumsTableViewCell.swift
//  InClass10
//
//  Created by Chung, Hyun Shik on 11/25/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//
protocol LikeButtonDelegate {
    func likebuttonin(cell:ForumsTableViewCell)
    func deletebutton(cell:ForumsTableViewCell)
    
}
import UIKit
import Firebase
class ForumsTableViewCell: UITableViewCell {
    var userID = Auth.auth().currentUser?.uid
    var ref = Database.database().reference()
    @IBOutlet weak var writerName: UILabel!
    @IBOutlet weak var writerMsg: UILabel!
    @IBOutlet weak var writerLikes: UILabel!
    var delegate:LikeButtonDelegate?
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var deleteButtonOutlet: UIButton!
    
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
   
    @IBAction func deleteButton(_ sender: Any) {
        delegate?.deletebutton(cell: self)
        
    }
    @IBAction func likeButton(_ sender: Any) {
        if button.isSelected{
          
        }
        delegate!.likebuttonin(cell: self)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
