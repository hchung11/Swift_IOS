//
//  AllForums.swift
//  InClass10
//
//  Created by Jerry Zacharias on 12/1/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import Foundation
class AllForums {
    var forumID:String?
    var name:String?
    var msg : String?
    var likes : Int?
    var userID:String?
    var likebutton:Int?
//    init(name:String, msg:String, likes:Int) {
//        self.name = name
//        self.msg = msg
//        self.likes = likes
//    }
}
