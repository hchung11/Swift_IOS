//
//  DetailForumViewController.swift
//  InClass10
//
//  Created by Jerry Zacharias on 12/1/19.
//  Copyright © 2019 Chung, Hyun Shik. All rights reserved.
//

import UIKit
import Firebase
class DetailForumViewController: UIViewController {
    
    @IBOutlet weak var detailName: UILabel!
    @IBOutlet weak var detailMsg: UILabel!
    @IBOutlet weak var detailLikes: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var detailForumid = ""
    var detailMSG = ""
    var detailLIKES = ""
    var detailNAME = ""
    var objectAforum = [Aforum]()
    var userID = Auth.auth().currentUser?.uid
    var ref = Database.database().reference()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let cellNib = UINib(nibName: "CommentTableViewCell", bundle: nil)
         tableView.register(cellNib, forCellReuseIdentifier: "commentCell")
        detailName.text = detailNAME
        detailLikes.text = detailLIKES
        detailMsg.text = detailMSG
 print("frome DetailForumViewController",detailForumid)
        
        
        //########################## ALL the Comment ##########################
        ref.child("forums").child(detailForumid).child("forum").observe(.value, with: { (snapshot) in
                     //print("3234897945====")
                     //print(snapshot)
                     self.objectAforum.removeAll()
                     if snapshot.value != nil{
                         for ch in snapshot.children{
                             let some = Aforum()
                             let snapshotData = ch as! DataSnapshot
                            some.unquID = snapshotData.key
                             if snapshotData.hasChild("name") {
                                some.currentuserName = snapshotData.childSnapshot(forPath: "name").value as? String
                             }
                             if snapshotData.hasChild("msg") {
                               some.msg = snapshotData.childSnapshot(forPath: "msg").value as? String
                             }
                             if snapshotData.hasChild("userID") {
                                some.currentUserID = snapshotData.childSnapshot(forPath: "userID").value as? String
                             }
                      
                             self.objectAforum.append(some)
                             
                         }
                         print("")
                         self.tableView.reloadData()
                     }
                 })
        //########################## ALL the Comment ##########################
        
        ref.child("forums").child(self.detailForumid).child("usersLikes").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            let likeButton = value?["likebutton"] as? Int
            if likeButton == 1{
                self.detailOLButton.setTitle("♥️", for: .normal )
            }else{
                self.detailOLButton.setTitle("♡", for: .normal )
            }
        }) { (error) in
            print(error.localizedDescription)
        }

    }
    
    @IBOutlet weak var commentTextField: UITextField!
    
    @IBAction func detailForumSubmitBut(_ sender: UIButton) {
        print("Somthgin Something")
              //******* put in the firebase database *******
              ref.child("usrs").child(userID!).observe(.value, with: { (snapshot) in
                // Get user value
                  let username = snapshot.childSnapshot(forPath: "name").value
                  print("print somthing",username!)
                  //Store all the forum msg in same data tree
                self.ref.child("forums").child(self.detailForumid).child("forum").childByAutoId().setValue(["msg": self.commentTextField.text! , "userID": self.userID! ,"name": username])
              //******* put in the firebase database *******
                  self.tableView.reloadData()
                // ...
                }) { (error) in
                  print(error.localizedDescription)
              }
              
    }
    
    
    @IBOutlet weak var detailOLButton: UIButton!
    @IBAction func detailheartButton(_ sender: Any) {
        ref.child("forums").child(self.detailForumid).child("usersLikes").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            // Get user value
            let value = snapshot.value as? NSDictionary
            let likeButton = value?["likebutton"] as? Int
            
            if likeButton == 1{
                // if like button is 1 then -1 whole LIKES
                self.ref.child("forums").child(self.detailForumid).updateChildValues(["like": Int(self.detailLIKES)! - 1])
                self.detailLikes.text = String( Int((self.detailLikes.text)!)! - 1)
            self.ref.child("forums").child(self.detailForumid).child("usersLikes").child(self.userID!).updateChildValues(["likebutton": -1])
                self.detailOLButton.titleLabel?.text = ""
                self.detailOLButton.setTitle("♡", for: .normal )
                
                
            }else{
                self.ref.child("forums").child(self.detailForumid).updateChildValues(["like": Int(self.detailLIKES)! + 1])
               self.detailLikes.text = String( Int((self.detailLikes.text)!)! + 1)
            self.ref.child("forums").child(self.detailForumid).child("usersLikes").child(self.userID!).updateChildValues(["likebutton": 1])
                self.detailOLButton.setTitle("♥️", for: .normal )
            }
            
            
            // ...
        }) { (error) in
            print(error.localizedDescription)
        }
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension DetailForumViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return  self.objectAforum.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "commentCell", for: indexPath) as! CommentTableViewCell
        cell.commentName.text =  objectAforum[indexPath.row].currentuserName
        cell.delegate = self
        cell.commentMsg.text =  objectAforum[indexPath.row].msg
//        let deleteButton = cell.viewWithTag(500) as! UIButton
//        if deleteButton.isTouchInside{
//            print("This is funckin awsom")
//        }
        if objectAforum[(indexPath.row)].currentUserID != userID{
            cell.commentDeleteButtonOutlook.isHidden = true
        }
        return cell
    }
    
    
}
extension DetailForumViewController: DeleteButtonDelegate{
    func deletebutton(cell: CommentTableViewCell) {
        let destroyAction = UIAlertAction(title: "OK",style: .default) { (action) in
        let indexPath = self.tableView.indexPath(for: cell)
            if self.objectAforum[(indexPath?.row)!].currentUserID == self.userID{
                self.ref.child("forums").child(self.detailForumid).child("forum").child(self.objectAforum[indexPath!.row].unquID!).removeValue()
            print("Delete all++++")
                print(self.objectAforum[indexPath!.row].unquID!)
          }
        }
        
              let cancelAction = UIAlertAction(title: "Cancel",
                        style: .cancel) { (action) in
               // Respond to user selection of the action
              }
             let alert = UIAlertController(title: "Delete the Threed?",
                           message: "",
                           preferredStyle: .actionSheet)
               alert.addAction(destroyAction)
               alert.addAction(cancelAction)
              self.present(alert, animated: true)
    }
    
}

